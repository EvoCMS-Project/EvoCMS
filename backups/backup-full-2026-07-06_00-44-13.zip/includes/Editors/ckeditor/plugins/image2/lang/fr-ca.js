/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'image2', 'fr-ca', {
	alt: 'Texte alternatif',
	btnUpload: 'Envoyer sur le serveur',
	captioned: 'Captioned image', // MISSING
	captionPlaceholder: 'Caption', // MISSING
	infoTab: 'Informations sur l\'image2',
	lockRatio: 'Verrouiller les proportions',
	menu: 'Propriétés de l\'image2',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Taille originale',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Propriétés de l\'image2',
	uploadTab: 'Téléverser',
	urlMissing: 'L\'URL de la source de l\'image est manquant.',
	altMissing: 'Alternative text is missing.' // MISSING
} );
