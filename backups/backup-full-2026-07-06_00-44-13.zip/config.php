<?php
$db_host = 'localhost'; 
$db_user = 'root'; 
$db_pass = 'Phpsql19850_'; 
$db_name = 'evocms'; 
$db_prefix = ''; 
$db_type = 'mysql'; 

// Debug mode active les options de dévelopement.
$debug_mode = false; 

// Préserve les erreurs PHP dans un fichier log.
$error_log = false; 

// Safe mode permets de désactiver tous les plugins et SSL.
$safe_mode = false; 
